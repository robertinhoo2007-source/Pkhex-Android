package com.example.pkhexandroid.gen3

import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Parser/writer for retail Generation III GBA save containers (including FireRed/LeafGreen). */
class FireRedSave private constructor(
    private val original: ByteArray,
    private val activeSectorOffsets: IntArray,
    private val storage: ByteArray
) {
    companion object {
        const val SECTOR_SIZE = 0x1000
        const val SECTOR_DATA_SIZE = 0xF80
        const val SECTOR_FOOTER = 0xFF4
        const val SIGNATURE = 0x08012025L
        const val BOX_COUNT = 14
        const val BOX_CAPACITY = 30
        const val BOX_POKEMON_SIZE = 80
        private const val STORAGE_SIZE = 0x83D0

        // FireRed/LeafGreen logical payload sizes, indexed by section ID.
        private val sectionSizes = intArrayOf(
            0xF24, 0xF80, 0xF80, 0xF80, 0xEE8,
            0xF80, 0xF80, 0xF80, 0xF80, 0xF80, 0xF80, 0xF80, 0xF80, 0x7D0
        )

        fun open(bytes: ByteArray): FireRedSave {
            require(bytes.size >= 14 * SECTOR_SIZE) { "El archivo es demasiado pequeño para un guardado GBA válido." }
            val candidates = mutableListOf<Slot>()
            val slotSpan = 14 * SECTOR_SIZE
            val bases = listOf(0).plus(if (bytes.size >= 2 * slotSpan) listOf(slotSpan) else emptyList())
            for (base in bases) validateSlot(bytes, base)?.let { candidates.add(it) }
            require(candidates.isNotEmpty()) { "No se encontró un bloque de guardado GBA válido (secciones/checksums)." }
            val active = candidates.maxWithOrNull { a, b -> java.lang.Long.compareUnsigned(a.counter, b.counter) }!!

            val logical = Array(14) { ByteArray(sectionSizes[it]) }
            for (id in 0 until 14) {
                val sectorOffset = active.offsets[id]
                System.arraycopy(bytes, sectorOffset, logical[id], 0, logical[id].size)
            }
            val storage = ByteArray(STORAGE_SIZE)
            var dest = 0
            for (id in 5..13) {
                System.arraycopy(logical[id], 0, storage, dest, logical[id].size)
                dest += logical[id].size
            }
            require(dest == STORAGE_SIZE) { "Estructura de almacenamiento inesperada." }
            return FireRedSave(bytes.copyOf(), active.offsets, storage)
        }

        private data class Slot(val offsets: IntArray, val counter: Long)

        private fun validateSlot(bytes: ByteArray, base: Int): Slot? {
            val offsets = IntArray(14) { -1 }
            var counter: Long? = null
            for (physical in 0 until 14) {
                val off = base + physical * SECTOR_SIZE
                if (off + SECTOR_SIZE > bytes.size) return null
                val id = u16(bytes, off + SECTOR_FOOTER)
                if (id !in 0..13 || offsets[id] != -1) return null
                if (u32(bytes, off + SECTOR_FOOTER + 4) != SIGNATURE) return null
                val thisCounter = u32(bytes, off + SECTOR_FOOTER + 8)
                if (counter != null && counter != thisCounter) return null
                counter = thisCounter
                val expected = checksum32(bytes, off, sectionSizes[id])
                if (u16(bytes, off + SECTOR_FOOTER + 2) != expected) return null
                offsets[id] = off
            }
            if (offsets.any { it < 0 }) return null
            return Slot(offsets, counter ?: return null)
        }

        private fun checksum32(data: ByteArray, offset: Int, length: Int): Int {
            var sum = 0L
            var p = offset
            val end = offset + length
            while (p + 3 < end) {
                sum = (sum + u32(data, p)) and 0xFFFFFFFFL
                p += 4
            }
            return (((sum ushr 16) + sum) and 0xFFFF).toInt()
        }

        private fun u16(a: ByteArray, p: Int) = (a[p].toInt() and 0xFF) or ((a[p + 1].toInt() and 0xFF) shl 8)
        private fun u32(a: ByteArray, p: Int): Long =
            (a[p].toLong() and 0xFF) or ((a[p + 1].toLong() and 0xFF) shl 8) or
            ((a[p + 2].toLong() and 0xFF) shl 16) or ((a[p + 3].toLong() and 0xFF) shl 24)
    }

    data class Pokemon(
        val personality: Long,
        val trainerId: Int,
        val secretId: Int,
        val species: Int,
        val heldItem: Int,
        val experience: Long,
        val friendship: Int,
        val moves: IntArray,
        val pp: IntArray,
        val evs: IntArray,
        val ivs: IntArray,
        val abilitySlot: Int,
        val isEgg: Boolean,
        val isEmpty: Boolean,
        val checksumValid: Boolean
    )

    fun getPokemon(box: Int, slot: Int): Pokemon {
        require(box in 0 until BOX_COUNT && slot in 0 until BOX_CAPACITY)
        val offset = 4 + (box * BOX_CAPACITY + slot) * BOX_POKEMON_SIZE
        return decodePokemon(storage.copyOfRange(offset, offset + BOX_POKEMON_SIZE))
    }

    /** Updates editable fields of an existing boxed Pokémon. Header identity is preserved. */
    fun updatePokemon(box: Int, slot: Int, edit: PokemonEdit) {
        require(box in 0 until BOX_COUNT && slot in 0 until BOX_CAPACITY)
        val offset = 4 + (box * BOX_CAPACITY + slot) * BOX_POKEMON_SIZE
        val record = storage.copyOfRange(offset, offset + BOX_POKEMON_SIZE)
        val decoded = decodePokemon(record)
        require(!decoded.isEmpty) { "La casilla está vacía." }
        require(decoded.checksumValid) { "El checksum del Pokémon no es válido; no se modificó." }
        val canonical = decryptCanonical(record)
        put16(canonical, 0, edit.species ?: decoded.species)
        put16(canonical, 2, edit.heldItem ?: decoded.heldItem)
        put32(canonical, 4, edit.experience ?: decoded.experience)
        for (i in 0..3) put16(canonical, 0x0C + i * 2, edit.moves?.getOrNull(i) ?: decoded.moves[i])
        for (i in 0..5) canonical[0x18 + i] = (edit.evs?.getOrNull(i) ?: decoded.evs[i]).coerceIn(0, 255).toByte()
        var ivWord = 0L
        for (i in 0..5) ivWord = ivWord or ((edit.ivs?.getOrNull(i) ?: decoded.ivs[i]).coerceIn(0, 31).toLong() shl (i * 5))
        ivWord = ivWord or ((decoded.isEgg.compareTo(false).toLong()) shl 30)
        ivWord = ivWord or ((decoded.abilitySlot.toLong() and 1L) shl 31)
        put32(canonical, 0x24, ivWord)
        val newRecord = encryptCanonical(record, canonical)
        System.arraycopy(newRecord, 0, storage, offset, BOX_POKEMON_SIZE)
    }

    fun export(): ByteArray {
        val out = original.copyOf()
        var source = 0
        for (id in 5..13) {
            val physicalOffset = activeSectorOffsets[id]
            val size = when (id) { 13 -> 0x7D0; else -> 0xF80 }
            System.arraycopy(storage, source, out, physicalOffset, size)
            put16(out, physicalOffset + SECTOR_FOOTER + 2, checksum32(out, physicalOffset, size))
            source += size
        }
        return out
    }

    private fun decodePokemon(record: ByteArray): Pokemon {
        if (record.all { it.toInt() == 0 }) return Pokemon(0,0,0,0,0,0,0, IntArray(4),IntArray(4),IntArray(6),IntArray(6),0,false,true,true)
        val c = decryptCanonical(record)
        val pid = u32(record, 0)
        val ot = u32(record, 4)
        val ivWord = u32(c, 0x24)
        var calculatedChecksum = 0
        for (i in 0 until 24) calculatedChecksum = (calculatedChecksum + u16(c, i * 2)) and 0xFFFF
        val checksumValid = calculatedChecksum == u16(record, 0x1C)
        return Pokemon(
            pid, (ot and 0xFFFF).toInt(), ((ot ushr 16) and 0xFFFF).toInt(),
            u16(c, 0), u16(c, 2), u32(c, 4), c[0x09].toInt() and 0xFF,
            IntArray(4) { u16(c, 0x0C + it * 2) }, IntArray(4) { c[0x14 + it].toInt() and 0xFF },
            IntArray(6) { c[0x18 + it].toInt() and 0xFF },
            IntArray(6) { ((ivWord ushr (it * 5)) and 31).toInt() },
            ((ivWord ushr 31) and 1).toInt(), ((ivWord ushr 30) and 1L) != 0L, false, checksumValid
        )
    }

    private fun decryptCanonical(record: ByteArray): ByteArray {
        val pid = u32(record, 0)
        val ot = u32(record, 4)
        val seed = pid xor ot
        val encrypted = ByteArray(48)
        for (i in 0 until 12) put32(encrypted, i * 4, u32(record, 0x20 + i * 4) xor seed)
        val order = PERMUTATIONS[(pid % 24).toInt()]
        val canonical = ByteArray(48)
        for (storedIndex in 0..3) {
            val canonicalIndex = "GAEM".indexOf(order[storedIndex])
            System.arraycopy(encrypted, storedIndex * 12, canonical, canonicalIndex * 12, 12)
        }
        return canonical
    }

    private fun encryptCanonical(header: ByteArray, canonical: ByteArray): ByteArray {
        val result = header.copyOf()
        val pid = u32(header, 0)
        val seed = pid xor u32(header, 4)
        val order = PERMUTATIONS[(pid % 24).toInt()]
        val encrypted = ByteArray(48)
        for (storedIndex in 0..3) {
            val canonicalIndex = "GAEM".indexOf(order[storedIndex])
            System.arraycopy(canonical, canonicalIndex * 12, encrypted, storedIndex * 12, 12)
        }
        for (i in 0 until 12) put32(result, 0x20 + i * 4, u32(encrypted, i * 4) xor seed)
        var checksum = 0
        for (i in 0 until 24) checksum = (checksum + u16(canonical, i * 2)) and 0xFFFF
        put16(result, 0x1C, checksum)
        return result
    }

    data class PokemonEdit(
        val species: Int? = null,
        val heldItem: Int? = null,
        val experience: Long? = null,
        val moves: IntArray? = null,
        val evs: IntArray? = null,
        val ivs: IntArray? = null
    )

    private fun u16(a: ByteArray, p: Int) = (a[p].toInt() and 0xFF) or ((a[p + 1].toInt() and 0xFF) shl 8)
    private fun u32(a: ByteArray, p: Int): Long =
        (a[p].toLong() and 0xFF) or ((a[p + 1].toLong() and 0xFF) shl 8) or
        ((a[p + 2].toLong() and 0xFF) shl 16) or ((a[p + 3].toLong() and 0xFF) shl 24)
    private fun put16(a: ByteArray, p: Int, v: Int) { a[p] = v.toByte(); a[p + 1] = (v ushr 8).toByte() }
    private fun put32(a: ByteArray, p: Int, v: Long) { for (i in 0..3) a[p + i] = (v ushr (8 * i)).toByte() }

    private val PERMUTATIONS = arrayOf(
        "GAEM","GAME","GEAM","GEMA","GMAE","GMEA",
        "AGEM","AGME","AEGM","AEMG","AMGE","AMEG",
        "EGAM","EGMA","EAGM","EAMG","EMGA","EMAG",
        "MGAE","MGEA","MAGE","MAEG","MEGA","MEAG"
    )
}
