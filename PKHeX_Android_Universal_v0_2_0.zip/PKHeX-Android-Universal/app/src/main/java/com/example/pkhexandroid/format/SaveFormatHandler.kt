package com.example.pkhexandroid.format

/**
 * Contrato para los módulos de formato por generación.
 * Cada implementación deberá identificar y validar el formato antes de permitir
 * cualquier escritura. No se debe inferir un juego únicamente por la extensión.
 */
interface SaveFormatHandler {
    val generation: Int
    val supportedTitles: Set<String>

    fun canRead(data: ByteArray): Boolean

    /** Devuelve datos estructurados cuando el parser de esta generación esté implementado. */
    fun parse(data: ByteArray): ParsedSave

    /** Debe preservar checksums, bloques y metadatos requeridos por el formato. */
    fun write(save: ParsedSave): ByteArray
}

data class ParsedSave(
    val title: String,
    val trainer: TrainerData?,
    val boxes: List<BoxData>,
    val rawMetadata: Map<String, String> = emptyMap()
)

data class TrainerData(
    val name: String,
    val publicId: Int,
    val secretId: Int
)

data class BoxData(
    val name: String,
    val pokemon: List<PokemonData>
)

data class PokemonData(
    val speciesId: Int,
    val nickname: String,
    val level: Int,
    val experience: Long,
    val natureId: Int?,
    val abilityId: Int?,
    val ivs: IntArray,
    val evs: IntArray,
    val moves: IntArray
)
