package com.example.pkhexandroid

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.pkhexandroid.gen3.FireRedSave
import com.example.pkhexandroid.gen3.FireRedSave.PokemonEdit

data class ImportedSave(
    val file: File,
    val originalName: String,
    val byteCount: Long,
    val sha256: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val saveDirectory = File(filesDir, "imported_saves").apply { mkdirs() }

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SaveHome(
                        saveDirectory = saveDirectory,
                        readUri = { uri -> contentResolver.openInputStream(uri) },
                        writeUri = { uri -> contentResolver.openOutputStream(uri, "wt") }
                    )
                }
            }
        }
    }
}

@Composable
private fun SaveHome(
    saveDirectory: File,
    readUri: (Uri) -> java.io.InputStream?,
    writeUri: (Uri) -> java.io.OutputStream?
) {
    var imported by remember { mutableStateOf<ImportedSave?>(null) }
    var fireRedSave by remember { mutableStateOf<FireRedSave?>(null) }
    var status by remember {
        mutableStateOf("Importa un archivo de guardado .sav o .dat. El archivo original no se modifica.")
    }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val importPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                try {
                    val result = withContext(Dispatchers.IO) {
                        val bytes = readUri(uri)?.use { it.readBytes() }
                            ?: error("No se pudo leer el archivo seleccionado.")
                        val displayName = uri.lastPathSegment
                            ?.substringAfterLast('/')
                            ?.substringAfterLast(':')
                            ?.ifBlank { "pokemon_save.bin" }
                            ?: "pokemon_save.bin"
                        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                        val destination = File(saveDirectory, "${System.currentTimeMillis()}_$safeName")
                        destination.writeBytes(bytes)
                        val digest = MessageDigest.getInstance("SHA-256")
                            .digest(bytes)
                            .joinToString("") { "%02x".format(it) }
                        val parsed = runCatching { FireRedSave.open(bytes) }.getOrNull()
                        Pair(ImportedSave(destination, displayName, bytes.size.toLong(), digest), parsed)
                    }
                    imported = result.first
                    fireRedSave = result.second
                    status = if (result.second != null) "Guardado GBA válido detectado. Editor de cajas de Rojo Fuego disponible." else "Copia importada, pero no se reconoció como un guardado GBA Gen III válido."
                } catch (e: Exception) {
                    status = "Error al importar: ${e.message ?: "error desconocido"}"
                } finally {
                    busy = false
                }
            }
        }
    }

    val exportPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val current = imported
        if (uri != null && current != null) {
            scope.launch {
                busy = true
                try {
                    withContext(Dispatchers.IO) {
                        val bytes = fireRedSave?.export() ?: current.file.readBytes()
                        writeUri(uri)?.use { output -> output.write(bytes) }
                            ?: error("No se pudo crear el archivo de destino.")
                    }
                    status = if (fireRedSave != null) "Guardado exportado con los cambios del editor de cajas." else "Copia exportada sin modificaciones."
                } catch (e: Exception) {
                    status = "Error al exportar: ${e.message ?: "error desconocido"}"
                } finally {
                    busy = false
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("PKHeX Android Universal", style = MaterialTheme.typography.headlineSmall)
            Text("Editor GBA inicial · versión 0.2.0", style = MaterialTheme.typography.bodyMedium)
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Partidas", style = MaterialTheme.typography.titleMedium)
                    Text("Importa una copia de tu guardado. Esta versión conserva y exporta el archivo sin alterar sus datos.")
                    Button(
                        onClick = { importPicker.launch(arrayOf("*/*")) },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Importar partida") }
                    if (imported != null) {
                        OutlinedButton(
                            onClick = {
                                val name = imported!!.originalName.substringBeforeLast('.', imported!!.originalName)
                                exportPicker.launch("${name}_copia")
                            },
                            enabled = !busy,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Exportar copia") }
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Estado", style = MaterialTheme.typography.titleMedium)
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(status)
                    imported?.let { save ->
                        HorizontalDivider()
                        Text("Archivo: ${save.originalName}")
                        Text("Tamaño: ${save.byteCount} bytes")
                        Text("SHA-256: ${save.sha256}", style = MaterialTheme.typography.bodySmall)
                        Text("Copia interna: ${save.file.name}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Text("Estado de compatibilidad", style = MaterialTheme.typography.titleMedium)
            Text("Implementado en esta versión: guardados de Pokémon Rojo Fuego y Verde Hoja de GBA. Los demás juegos aún no tienen motor.")
        }
        items(listOf(
            "Gen I–II · formatos clásicos",
            "Gen III · GBA",
            "Gen IV–V · Nintendo DS",
            "Gen VI–VII · Nintendo 3DS",
            "Gen VIII–IX · Nintendo Switch"
        )) { generation ->
            ListItem(
                headlineContent = { Text(generation) },
                supportingContent = { Text("Módulo de lectura y edición pendiente de implementar") }
            )
        }
        fireRedSave?.let { save ->
            item { FireRedBoxEditor(save) }
        }
        item {
            Text(
                "Limitaciones: esta versión edita Pokémon existentes en las cajas del PC. No edita el equipo, entrenador, mochila, apodos ni legalidad. Usa siempre una copia del guardado y comprueba el resultado en el emulador.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}


@Composable
private fun FireRedBoxEditor(save: FireRedSave) {
    var boxText by remember(save) { mutableStateOf("1") }
    var slotText by remember(save) { mutableStateOf("1") }
    var speciesText by remember(save) { mutableStateOf("") }
    var itemText by remember(save) { mutableStateOf("") }
    var expText by remember(save) { mutableStateOf("") }
    var movesText by remember(save) { mutableStateOf("0,0,0,0") }
    var evsText by remember(save) { mutableStateOf("0,0,0,0,0,0") }
    var ivsText by remember(save) { mutableStateOf("0,0,0,0,0,0") }
    var message by remember(save) { mutableStateOf("Selecciona una casilla de una caja.") }
    var revision by remember(save) { mutableIntStateOf(0) }

    val box = (boxText.toIntOrNull() ?: 1).coerceIn(1, 14) - 1
    val slot = (slotText.toIntOrNull() ?: 1).coerceIn(1, 30) - 1
    val pokemon = remember(box, slot, revision, save) { save.getPokemon(box, slot) }

    LaunchedEffect(save, box, slot, revision) {
        if (!pokemon.isEmpty) {
            speciesText = pokemon.species.toString()
            itemText = pokemon.heldItem.toString()
            expText = pokemon.experience.toString()
            movesText = pokemon.moves.joinToString(",")
            evsText = pokemon.evs.joinToString(",")
            ivsText = pokemon.ivs.joinToString(",")
            message = "Pokémon cargado. Edita los campos y pulsa aplicar."
        } else {
            speciesText = ""
            itemText = ""
            expText = ""
            movesText = "0,0,0,0"
            evsText = "0,0,0,0,0,0"
            ivsText = "0,0,0,0,0,0"
            message = "Esta casilla está vacía. En esta primera implementación solo se editan Pokémon existentes."
        }
    }

    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Editor de cajas · Rojo Fuego / Gen III", style = MaterialTheme.typography.titleLarge)
            Text("Esta primera fase edita Pokémon del PC. El equipo de seis Pokémon y los datos del entrenador aún no están implementados.", style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(boxText, { boxText = it.filter(Char::isDigit).take(2) }, label = { Text("Caja (1–14)") }, modifier = Modifier.weight(1f), singleLine = true)
                OutlinedTextField(slotText, { slotText = it.filter(Char::isDigit).take(2) }, label = { Text("Casilla (1–30)") }, modifier = Modifier.weight(1f), singleLine = true)
            }
            if (pokemon.isEmpty) {
                Text("Casilla vacía", color = MaterialTheme.colorScheme.secondary)
            } else {
                Text("PID: ${pokemon.personality.toString(16).uppercase()} · EO: ${pokemon.trainerId}/${pokemon.secretId}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(speciesText, { speciesText = it.filter(Char::isDigit).take(3) }, label = { Text("Especie (ID interno)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(itemText, { itemText = it.filter(Char::isDigit).take(4) }, label = { Text("Objeto equipado (ID)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(expText, { expText = it.filter(Char::isDigit).take(8) }, label = { Text("Experiencia") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(movesText, { movesText = it }, label = { Text("Movimientos: 4 IDs separados por coma") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(evsText, { evsText = it }, label = { Text("EV HP, Atq, Def, Vel, AtEsp, DefEsp") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(ivsText, { ivsText = it }, label = { Text("IV HP, Atq, Def, Vel, AtEsp, DefEsp (0–31)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Text("Naturaleza: ${pokemon.personality.mod(25)} (derivada del PID; no editable aún) · Habilidad: ranura ${pokemon.abilitySlot}", style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = {
                        try {
                            fun csv(text: String, count: Int, max: Int): IntArray {
                                val values = text.split(",").map { it.trim().toInt() }
                                require(values.size == count) { "Se requieren $count valores separados por coma." }
                                require(values.all { it in 0..max }) { "Valores fuera del rango permitido (0–$max)." }
                                return values.toIntArray()
                            }
                            val species = speciesText.toInt().also { require(it in 1..386) { "La especie debe estar entre 1 y 386." } }
                            val item = itemText.toInt().also { require(it in 0..376) { "El objeto debe estar entre 0 y 376." } }
                            val exp = expText.toLong().also { require(it in 0..1_640_000L) { "Experiencia fuera del rango admitido." } }
                            save.updatePokemon(
                                box, slot,
                                PokemonEdit(
                                    species = species,
                                    heldItem = item,
                                    experience = exp,
                                    moves = csv(movesText, 4, 354),
                                    evs = csv(evsText, 6, 252).also { require(it.sum() <= 510) { "Los EV totales no pueden superar 510." } },
                                    ivs = csv(ivsText, 6, 31)
                                )
                            )
                            revision++
                            message = "Cambios aplicados en memoria. Exporta el guardado para conservarlos."
                        } catch (e: Exception) {
                            message = "No se pudo aplicar: ${e.message ?: "datos inválidos"}"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Aplicar cambios a este Pokémon") }
            }
            Text(message, style = MaterialTheme.typography.bodySmall)
        }
    }
}
