# PKHeX Android Universal — prototype 0.2.0

Android app base in Kotlin + Jetpack Compose.

## Implemented in this build

- Android document picker import/export.
- Keeps an untouched imported source copy in app-private storage.
- SHA-256 fingerprint for the imported file.
- Generation III GBA save container reader for the standard 14-section rotating save slots.
- Active slot selection by save counter, section ID mapping, signature and section checksum validation.
- FireRed/LeafGreen PC storage reconstruction (14 boxes × 30 slots).
- Generation III boxed Pokémon (80-byte PK3) decryption, block unshuffle, checksum validation, and re-encryption.
- Editor for existing PC Pokémon: species ID, held item ID, experience, four move IDs, six EVs and six IVs.
- Exports a new save copy, rewriting PC storage sectors and recalculating their section checksums. Original imported file remains unchanged.
- GitHub Actions workflow to build a debug APK.

## Important limitations

This is an early FireRed/LeafGreen Gen III editor, not a full PKHeX replacement. It does not yet edit party Pokémon, trainer data, inventory, Pokédex, flags, box names, ribbons, nickname/OT text, nature/PID, abilities, or validate legal encounter data. It has not yet been verified against a broad set of real emulator saves on-device. Keep backups and test only on duplicate saves.

The parser uses the FireRed/LeafGreen section lengths. It should not be treated as a Ruby/Sapphire/Emerald editor until their differing SaveBlock layouts are implemented and tested.

## Build APK

Requirements: Android Studio, JDK 17, Android SDK 35.

1. Open this project folder in Android Studio.
2. Wait for Gradle sync.
3. Choose `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Debug APK path: `app/build/outputs/apk/debug/app-debug.apk`.

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml` to compile and publish the debug APK as a workflow artifact.
